import * as THREE from 'three'

export const addBoilerPlateMesh = () => {
	const box = new THREE.BoxGeometry(1, 1, 1)
	const boxMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 })
}

// function addBoilerPlateMesh(){

// }
